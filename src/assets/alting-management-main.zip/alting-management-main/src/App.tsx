import { useEffect, useRef, useState } from 'react'
import { Activity, AlertTriangle, ArrowUpRight, Bus, Check, ChevronRight, CloudRain, Compass, Inbox, LocateFixed, MapPin, MessageSquare, Plus, Send, Settings, Sparkles, Sun, Ticket, Trash2, Wind, X } from 'lucide-react'
import { createClient, type SupabaseClient } from '@supabase/supabase-js'

type Conversation = { id: string; title: string; created_at: string; updated_at: string }
type Message = { id: string; conversation_id: string; role: 'user' | 'assistant'; content: string; card_type: string | null; card_data: unknown; created_at: string }
type Level = 'High' | 'Medium' | 'Low'
type WeatherSummary = { temp: number; condition: string; feelsLike: number }

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined
const db: SupabaseClient | null = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null

const suggestions = [
  { label: "Book a train to New York", icon: Ticket },
  { label: "Find buses from Boston", icon: Bus },
  { label: "Weather in Boston", icon: CloudRain },
  { label: "Show road reports", icon: AlertTriangle },
  { label: "Connect my email", icon: Inbox },
  { label: "Where is Grand Central?", icon: MapPin },
]

export default function App() {
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [activeId, setActiveId] = useState<string | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [pos, setPos] = useState<{ lat: number; lng: number; accuracy: number } | null>(null)
  const [tracking, setTracking] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [toast, setToast] = useState('')
  const [now, setNow] = useState(() => new Date())
  const [weatherSummary, setWeatherSummary] = useState<WeatherSummary | null>(null)
  const startedAt = useRef(Date.now())
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => { void loadConversations() }, [])
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000)
    return () => window.clearInterval(id)
  }, [])
  useEffect(() => {
    const loadWeatherSummary = async () => {
      if (!supabaseUrl || !supabaseKey) return
      try {
        const res = await fetch(`${supabaseUrl}/functions/v1/waypoint-agent`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${supabaseKey}` }, body: JSON.stringify({ action: { type: 'weather', location: 'current location' } }) })
        if (!res.ok) return
        const data = await res.json() as { card_data?: { current?: { temp?: number; condition?: string; feels_like?: number } } }
        const current = data.card_data?.current
        if (typeof current?.temp === 'number' && typeof current.condition === 'string' && typeof current.feels_like === 'number') setWeatherSummary({ temp: current.temp, condition: current.condition, feelsLike: current.feels_like })
      } catch {
        setWeatherSummary(null)
      }
    }
    void loadWeatherSummary()
  }, [])
  useEffect(() => { if (activeId) void loadMessages(activeId) }, [activeId])
  useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight }, [messages, loading])
  useEffect(() => { if (!toast) return; const id = setTimeout(() => setToast(''), 3000); return () => clearTimeout(id) }, [toast])
  useEffect(() => {
    if (!tracking || !navigator.geolocation) return
    const id = navigator.geolocation.watchPosition(({ coords }) => {
      const p = { lat: coords.latitude, lng: coords.longitude, accuracy: coords.accuracy }
      setPos(p)
      if (db) void db.from('location_tracks').insert({ lat: p.lat, lng: p.lng, accuracy: p.accuracy, session_id: 'waypoint-live' }).then()
    }, () => { setTracking(false); setToast('Location not available') }, { enableHighAccuracy: true })
    return () => navigator.geolocation.clearWatch(id)
  }, [tracking])

  const loadConversations = async () => {
    if (!db) return
    const { data } = await db.from('conversations').select('*').order('updated_at', { ascending: false }).limit(50)
    if (data && data.length > 0) { setConversations(data as Conversation[]); setActiveId((data[0] as Conversation).id) }
  }
  const loadMessages = async (id: string) => {
    if (!db) return
    const { data } = await db.from('conversation_messages').select('*').eq('conversation_id', id).order('created_at', { ascending: true })
    setMessages((data || []) as Message[])
  }
  const newConversation = async (): Promise<string | null> => {
    if (!db) return null
    const { data, error } = await db.from('conversations').insert({ title: 'New conversation' }).select().single()
    if (error || !data) return null
    const conv = data as Conversation
    setConversations(prev => [conv, ...prev])
    setActiveId(conv.id)
    setMessages([])
    return conv.id
  }
  const deleteConversation = async (id: string) => {
    if (!db) return
    await db.from('conversations').delete().eq('id', id)
    setConversations(prev => prev.filter(c => c.id !== id))
    if (activeId === id) { setActiveId(null); setMessages([]) }
    setToast('Conversation deleted')
  }
  const toggleTrack = () => { setTracking(v => !v); setToast(tracking ? 'Route tracking paused' : 'Route tracking active') }

  const send = async () => {
    const text = input.trim()
    if (!text || loading) return
    setInput('')
    let convId = activeId
    if (!convId) convId = await newConversation()
    if (!convId) return

    const userMsg: Message = { id: 'temp-user', conversation_id: convId, role: 'user', content: text, card_type: null, card_data: null, created_at: new Date().toISOString() }
    setMessages(prev => [...prev, userMsg])
    setLoading(true)

    if (db) {
      await db.from('conversation_messages').insert({ conversation_id: convId, role: 'user', content: text })
      if (messages.length === 0) {
        const title = text.slice(0, 50)
        await db.from('conversations').update({ title, updated_at: new Date().toISOString() }).eq('id', convId)
        setConversations(prev => prev.map(c => c.id === convId ? { ...c, title } : c))
      } else {
        await db.from('conversations').update({ updated_at: new Date().toISOString() }).eq('id', convId)
      }
    }

    try {
      const url = `${supabaseUrl}/functions/v1/waypoint-agent`
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${supabaseKey}` },
        body: JSON.stringify({ messages: [...messages, { role: 'user', content: text }], user_lat: pos?.lat, user_lng: pos?.lng }),
      })
      if (!res.ok) throw new Error(`Request failed (${res.status})`)
      const data = await res.json()
      const reply = data.response || 'Sorry, I could not process that request.'
      const cardType = data.card_type || null
      const cardData = data.card_data || null

      const assistantMsg: Message = { id: 'temp-asst', conversation_id: convId, role: 'assistant', content: reply, card_type: cardType, card_data: cardData, created_at: new Date().toISOString() }
      setMessages(prev => [...prev, assistantMsg])

      if (db) {
        await db.from('conversation_messages').insert({ conversation_id: convId, role: 'assistant', content: reply, card_type: cardType, card_data: cardData })
        await db.from('conversations').update({ updated_at: new Date().toISOString() }).eq('id', convId)
      }
    } catch {
      const errMsg: Message = { id: 'temp-err', conversation_id: convId, role: 'assistant', content: 'I could not reach the network right now. Please try again.', card_type: null, card_data: null, created_at: new Date().toISOString() }
      setMessages(prev => [...prev, errMsg])
    } finally {
      setLoading(false)
    }
  }

  return <div className="agent-app">
    <aside className={sidebarOpen ? 'conv-bar open' : 'conv-bar'}>
      <div className="conv-bar-head">
        <div className="brand"><div className="logo"><Compass size={18}/></div><div><strong>TRAVBUD</strong><small>AI TRAVEL AGENT</small></div></div>
        <button className="close-mobile" onClick={() => setSidebarOpen(false)}><X size={18}/></button>
      </div>
      <button className="new-conv" onClick={() => { void newConversation(); setSidebarOpen(false) }}><Plus size={16}/> New conversation</button>
      <div className="conv-list">{conversations.map(c => <div key={c.id} className={activeId === c.id ? 'conv-item active' : 'conv-item'} onClick={() => { setActiveId(c.id); setSidebarOpen(false) }}><MessageSquare size={14}/><span>{c.title}</span><button className="conv-delete" onClick={e => { e.stopPropagation(); void deleteConversation(c.id) }}><Trash2 size={13}/></button></div>)}</div>
      <div className="conv-bar-foot">
        <div className={`track-toggle ${tracking ? 'on' : ''}`} onClick={toggleTrack}><LocateFixed size={14}/> {tracking ? 'Tracking on' : 'Route tracking'}</div>
        <button className="settings-btn" onClick={() => setShowSettings(true)}><Settings size={14}/> Settings</button>
      </div>
    </aside>

    <main>
      <header>
        <button className="menu-btn" onClick={() => setSidebarOpen(true)}><Compass size={20}/></button>
        <div className="agent-status"><span className={`status-dot ${tracking ? 'live' : ''}`}/><span>{tracking ? 'Agent live · tracking route' : 'Agent ready'}</span></div>
        <div className="header-actions"><button className={`icon-btn ${tracking ? 'active' : ''}`} onClick={toggleTrack} title="Toggle route tracking"><LocateFixed size={16}/></button><button className="icon-btn" onClick={() => setShowSettings(true)}><Settings size={16}/></button></div>
      </header>

      <div className="chat-scroll" ref={scrollRef}>
        {messages.length === 0 && !loading ? (
          <div className="welcome-screen">
            <div className="welcome-nav"><span className="welcome-mark"><Compass size={16}/></span><span>TRAVBUD</span><div><span>AGENT</span><span>CAPABILITIES</span><span>NETWORK</span></div><button onClick={toggleTrack}>{tracking ? 'TRACKING LIVE' : 'LIVE STATUS'} <ArrowUpRight size={13}/></button></div>
            <div className="welcome-stage"><div className="stage-glow"/><div className="welcome-orb"><Sparkles size={32}/></div><div className="wordmark">TRAVBUD</div><div className="stage-line">AI TRAVEL INTELLIGENCE · ONLINE</div></div>
            <h1>Where are you going next?</h1>
            <p>Your travel copilot for finding routes, ordering tickets, checking conditions, and keeping every trip detail in one place.</p>
            <div className="welcome-grid">{suggestions.slice(0, 4).map(s => <button key={s.label} className="welcome-card" onClick={() => setInput(s.label)}><s.icon size={18}/><span>{s.label}</span><ArrowUpRight size={13}/></button>)}</div>
            {pos && <div className="pos-badge"><LocateFixed size={13}/> Location active · {Math.round(pos.accuracy)}m accuracy</div>}
            <StatusDeck now={now} startedAt={startedAt.current} tracking={tracking} connected={Boolean(db)} weather={weatherSummary} />
            <div className="welcome-footer"><span>BUILT FOR THE MOMENT BETWEEN HERE AND THERE</span><span>SCROLL TO EXPLORE <ChevronRight size={12}/></span></div>
          </div>
        ) : (
          <div className="messages">{messages.map(m => <MessageBubble key={m.id} msg={m} />)}{loading && <div className="msg assistant"><div className="msg-avatar"><Sparkles size={14}/></div><div className="thinking"><span/><span/><span/></div></div>}</div>
        )}
      </div>

      <div className="input-bar">
        <div className="input-wrap">
          <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="Book tickets, plan a route, or ask about your trip…"/>
          <button className="send-btn" onClick={send} disabled={loading || !input.trim()}><Send size={18}/></button>
        </div>
        <div className="quick-chips">{suggestions.slice(0, 4).map(s => <button key={s.label} onClick={() => setInput(s.label)}><s.icon size={12}/> {s.label}</button>)}</div>
      </div>
    </main>

    {showSettings && <SettingsPanel onClose={() => setShowSettings(false)} tracking={tracking} toggleTrack={toggleTrack} pos={pos} />}
    {toast && <div className="toast"><Check size={15}/> {toast}</div>}
  </div>
}

function formatClock(date: Date): string {
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
}

function formatUptime(startedAt: number, now: number): string {
  const totalMinutes = Math.floor((now - startedAt) / 60000)
  const hours = Math.floor(totalMinutes / 60).toString().padStart(2, '0')
  const minutes = (totalMinutes % 60).toString().padStart(2, '0')
  return `${hours}h ${minutes}m`
}

function StatusDeck({ now, startedAt, tracking, connected, weather }: { now: Date; startedAt: number; tracking: boolean; connected: boolean; weather: WeatherSummary | null }) {
  return <div className="status-deck">
    <div className="status-card"><div className="status-card-top"><ClockIcon/><span>LOCAL TIME</span><i className="status-live-dot"/></div><strong>{formatClock(now)}</strong><small>{now.toLocaleDateString([], { weekday: 'long', month: 'short', day: 'numeric' })}</small></div>
    <div className="status-card"><div className="status-card-top"><CloudRain size={14}/><span>WEATHER</span><i className="status-live-dot"/></div><strong>{weather ? `${Math.round(weather.temp)}°` : '—'}</strong><small>{weather ? `${weather.condition} · feels ${Math.round(weather.feelsLike)}°` : 'Syncing conditions'}</small></div>
    <div className="status-card"><div className="status-card-top"><Activity size={14}/><span>SYSTEM STATUS</span><i className="status-live-dot"/></div><strong>{connected ? 'Operational' : 'Offline mode'}</strong><small>{connected ? 'TravBud network connected' : 'Local experience only'}</small></div>
    <div className="status-card"><div className="status-card-top"><LocateFixed size={14}/><span>ROUTE SIGNAL</span><i className={`status-live-dot ${tracking ? '' : 'muted'}`}/></div><strong>{tracking ? 'Tracking' : 'Standby'}</strong><small>{tracking ? 'Live safety monitoring on' : 'Enable when you travel'}</small></div>
    <div className="status-card"><div className="status-card-top"><Sparkles size={14}/><span>AGENT UPTIME</span><i className="status-live-dot"/></div><strong>{formatUptime(startedAt, now.getTime())}</strong><small>Session running smoothly</small></div>
  </div>
}

function ClockIcon() {
  return <span className="clock-icon" aria-hidden="true" />
}

function formatMessage(content: string): React.ReactNode {
  return content.split(/(\*\*[^*]+\*\*)|(\n)/g).filter(Boolean).map((part, index) => {
    if (part === '\n') return <br key={index}/>
    if (part.startsWith('**') && part.endsWith('**')) return <strong key={index}>{part.slice(2, -2)}</strong>
    return <span key={index}>{part}</span>
  })
}

function MessageBubble({ msg }: { msg: Message }) {
  const isUser = msg.role === 'user'
  return <div className={isUser ? 'msg user' : 'msg assistant'}>
    {!isUser && <div className="msg-avatar"><Sparkles size={14}/></div>}
    <div className="msg-content">
      <div className="msg-text">{formatMessage(msg.content)}</div>
      {!isUser && msg.card_type && <ResultCard type={msg.card_type} data={msg.card_data} />}
    </div>
  </div>
}

function ResultCard({ type, data }: { type: string; data: unknown }) {
  const d = data as Record<string, unknown>
  if (type === 'weather') return <WeatherCard data={d} />
  if (type === 'geocode') return <GeocodeCard data={d} />
  if (type === 'reports') return <ReportsCard data={d} />
  if (type === 'inbox') return <InboxCard data={d} />
  if (type === 'report_created') return <ReportCreatedCard data={d} />
  if (type === 'ticket_order') return <TicketOrderCard data={d} />
  return null
}

function WeatherCard({ data }: { data: Record<string, unknown> }) {
  const current = data.current as { temp: number; humidity: number; code: number; condition: string; wind: number; feels_like: number }
  const forecast = data.forecast as { date: string; condition: string; code: number; high: number; low: number; rain_chance: number }[]
  const location = data.location as string
  return <div className="card weather-card">
    <div className="card-head"><CloudRain size={15}/> <span>Live weather · {location}</span></div>
    <div className="weather-current">
      <div className="weather-icon"><WeatherGlyph code={current.code} /></div>
      <div className="weather-temp">{Math.round(current.temp)}°</div>
      <div className="weather-meta"><strong>{current.condition}</strong><span>Feels {Math.round(current.feels_like)}° · {current.humidity}% humidity</span><span><Wind size={11}/> {Math.round(current.wind)} km/h</span></div>
    </div>
    <div className="weather-forecast">{forecast.map(f => <div key={f.date} className="forecast-day"><span>{new Date(f.date).toLocaleDateString('en', { weekday: 'short' })}</span><WeatherGlyph code={f.code} small /><span className="forecast-temps">{Math.round(f.high)}° / {Math.round(f.low)}°</span><span className="forecast-rain">{f.rain_chance}%</span></div>)}</div>
  </div>
}

function WeatherGlyph({ code, small }: { code: number; small?: boolean }) {
  if (code === 0) return <Sun size={small ? 16 : 28} className="weather-glyph sun" />
  if (code >= 51 && code <= 67 || code >= 80 && code <= 82) return <CloudRain size={small ? 16 : 28} className="weather-glyph rain" />
  return <CloudRain size={small ? 16 : 28} className="weather-glyph cloud" />
}

function GeocodeCard({ data }: { data: Record<string, unknown> }) {
  const lat = data.lat as number, lng = data.lng as number, label = data.label as string
  return <div className="card geocode-card">
    <div className="card-head"><MapPin size={15}/> <span>{label}</span></div>
    <div className="mini-map" role="img" aria-label={`Map location for ${label}`}>
      <div className="map-grid" />
      <div className="map-route route-one" />
      <div className="map-route route-two" />
      <div className="map-marker"><span /></div>
      <div className="map-label">{label}</div>
    </div>
    <div className="geocode-coords">{lat.toFixed(4)}, {lng.toFixed(4)}</div>
  </div>
}

function ReportsCard({ data }: { data: Record<string, unknown> }) {
  const reports = data.reports as { id: string; title: string; location_label: string; level: Level; category: string; lat: number | null; lng: number | null }[]
  return <div className="card reports-card">
    <div className="card-head"><AlertTriangle size={15}/> <span>{reports.length} road reports</span></div>
    {reports.map(r => <div key={r.id} className="report-item"><span className={`level-badge ${r.level.toLowerCase()}`}/><div><strong>{r.title}</strong><span><MapPin size={10}/> {r.location_label}</span></div><em className={`level-tag ${r.level.toLowerCase()}`}>{r.level}</em></div>)}
  </div>
}

function InboxCard({ data }: { data: Record<string, unknown> }) {
  const emails = data.emails as { sender: string; subject: string; preview: string; category: string }[]
  return <div className="card inbox-card">
    <div className="card-head"><Inbox size={15}/> <span>{emails.length} travel messages</span></div>
    {emails.map((e, i) => <div key={i} className="email-item"><span className="email-avatar">{e.sender[0].toUpperCase()}</span><div><strong>{e.subject}</strong><span>{e.sender} · {e.category}</span></div></div>)}
  </div>
}

function ReportCreatedCard({ data }: { data: Record<string, unknown> }) {
  const r = data.report as { id: string; title: string; location_label: string; severity: string; category: string }
  return <div className="card created-card"><div className="card-head"><Check size={15}/> <span>Report submitted</span></div><div className="created-detail"><strong>{r.title}</strong><span><MapPin size={11}/> {r.location_label}</span><span>Severity: {r.severity} · Category: {r.category}</span></div></div>
}

function TicketOrderCard({ data }: { data: Record<string, unknown> }) {
  const order = data.order as { origin: string; destination: string; travel_mode: string; departure_date: string; traveler_count: number; fare_cents: number; currency: string; confirmation_code: string }
  return <div className="card ticket-card"><div className="card-head"><Ticket size={15}/> <span>TravBud ticket confirmed</span><span className="confirmed-pill">CONFIRMED</span></div><div className="ticket-route"><div><small>FROM</small><strong>{order.origin}</strong></div><div className="route-arrow"><span/><ArrowUpRight size={15}/></div><div><small>TO</small><strong>{order.destination}</strong></div></div><div className="ticket-meta"><span><strong>{order.travel_mode.toUpperCase()}</strong> · {new Date(order.departure_date).toLocaleDateString('en', { month: 'short', day: 'numeric', year: 'numeric' })}</span><span>{order.traveler_count} traveler{order.traveler_count === 1 ? '' : 's'} · {order.currency} {(order.fare_cents / 100).toFixed(2)}</span></div><div className="ticket-confirmation"><span>CONFIRMATION</span><strong>{order.confirmation_code}</strong></div></div>
}

function SettingsPanel({ onClose, tracking, toggleTrack, pos }: { onClose: () => void; tracking: boolean; toggleTrack: () => void; pos: { accuracy: number } | null }) {
  return <div className="backdrop" onClick={onClose}><div className="settings-panel" onClick={e => e.stopPropagation()}>
    <div className="settings-head"><h2>Agent settings</h2><button onClick={onClose}><X size={18}/></button></div>
    <div className="settings-body">
      <div className="setting-group"><h3><LocateFixed size={15}/> Route tracking</h3><p>When enabled, the agent monitors your live GPS position and records it for safety.</p><button className={`setting-toggle ${tracking ? 'on' : ''}`} onClick={toggleTrack}><span className="toggle-knob"/></button>{pos && <small className="pos-info"><Check size={12}/> Last accuracy: {Math.round(pos.accuracy)}m</small>}</div>
      <div className="setting-group"><h3><CloudRain size={15}/> Weather API</h3><p>Connected to Open-Meteo for live forecasts.</p><button className="setting-toggle on"><span className="toggle-knob"/></button></div>
      <div className="setting-group"><h3><MapPin size={15}/> Geocoding API</h3><p>Connected to Open-Meteo for place search.</p><button className="setting-toggle on"><span className="toggle-knob"/></button></div>
      <div className="setting-group"><h3><Inbox size={15}/> Email connection</h3><p>Ask the agent to "connect my email" to sync travel messages.</p><button className="setting-toggle on"><span className="toggle-knob"/></button></div>
      <div className="setting-group"><h3><Activity size={15}/> Data persistence</h3><p>Conversations are saved automatically and synced across sessions.</p><button className="setting-toggle on"><span className="toggle-knob"/></button></div>
    </div>
  </div></div>
}
