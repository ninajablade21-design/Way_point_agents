/*
# Create TravBud ticket orders

1. New Tables
- `ticket_orders` stores ticket requests created through the TravBud AI agent.
- `id` is the order identifier.
- `origin` and `destination` store the requested route.
- `travel_mode` stores bus, train, flight, or ferry.
- `departure_date` stores the requested departure date.
- `traveler_count` stores the number of travelers.
- `fare_cents` stores the displayed fare in cents.
- `currency` stores the fare currency.
- `status` stores the order state.
- `confirmation_code` stores the generated TravBud confirmation.
- `created_at` stores when the order was created.

2. Security
- Row level security is enabled.
- This app has no sign-in screen, so the intentional shared demo booking table is readable and writable by anon and authenticated clients.
- CRUD permissions are defined as four separate policies.

3. Important Notes
- Orders are persisted so the agent can show a booking history after reloads.
- The current catalog is a TravBud demo inventory; live carrier payment is not connected.
*/

CREATE TABLE IF NOT EXISTS ticket_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  origin text NOT NULL,
  destination text NOT NULL,
  travel_mode text NOT NULL DEFAULT 'train',
  departure_date date NOT NULL,
  traveler_count integer NOT NULL DEFAULT 1 CHECK (traveler_count > 0 AND traveler_count <= 9),
  fare_cents integer NOT NULL CHECK (fare_cents >= 0),
  currency text NOT NULL DEFAULT 'USD',
  status text NOT NULL DEFAULT 'confirmed',
  confirmation_code text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ticket_orders_created_idx ON ticket_orders (created_at DESC);

ALTER TABLE ticket_orders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_ticket_orders" ON ticket_orders;
CREATE POLICY "anon_select_ticket_orders" ON ticket_orders FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_ticket_orders" ON ticket_orders;
CREATE POLICY "anon_insert_ticket_orders" ON ticket_orders FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_ticket_orders" ON ticket_orders;
CREATE POLICY "anon_update_ticket_orders" ON ticket_orders FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_ticket_orders" ON ticket_orders;
CREATE POLICY "anon_delete_ticket_orders" ON ticket_orders FOR DELETE
  TO anon, authenticated USING (true);
