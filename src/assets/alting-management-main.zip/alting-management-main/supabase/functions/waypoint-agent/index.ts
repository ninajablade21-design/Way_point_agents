import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

type AgentAction =
  | { type: "weather"; location: string; lat?: number; lng?: number }
  | { type: "geocode"; query: string }
  | { type: "search_reports"; query: string }
  | { type: "summarize_inbox" }
  | { type: "create_report"; title: string; place: string; category: string; severity: string }
  | { type: "connect_email" }
  | { type: "book_ticket"; origin: string; destination: string; travel_mode: string; departure_date: string; traveler_count: number }
  | { type: "chat"; text: string };

type ChatMessage = { role: "user" | "assistant"; content: string };

function classifyIntent(input: string): AgentAction {
  const lower = input.toLowerCase().trim();
  if (lower.includes("book") || lower.includes("order") || lower.includes("reserve") || lower.includes("ticket")) {
    const route = input.match(/from\\s+(.+?)\\s+to\\s+(.+?)(?:\\s+(?:on|for)\\s+|$)/i);
    const dateMatch = input.match(/(?:on|for)\\s+([a-z0-9 ,/-]+)/i);
    const travelerMatch = input.match(/(\\d+)\\s*(?:traveler|passenger|person)/i);
    const mode = lower.includes("bus") ? "bus" : lower.includes("flight") || lower.includes("plane") ? "flight" : lower.includes("ferry") ? "ferry" : "train";
    const departure = dateMatch ? new Date(dateMatch[1].trim()) : new Date(Date.now() + 86400000 * 7);
    return { type: "book_ticket", origin: route?.[1]?.trim() || "", destination: route?.[2]?.trim() || "", travel_mode: mode, departure_date: Number.isNaN(departure.getTime()) ? new Date(Date.now() + 86400000 * 7).toISOString().slice(0, 10) : departure.toISOString().slice(0, 10), traveler_count: Math.min(9, Math.max(1, Number(travelerMatch?.[1] || 1))) };
  }
  if (lower.includes("report a") || lower.includes("submit a") || lower.includes("log a") || lower.includes("add a report") || lower.includes("new hazard")) {
    const titleMatch = input.match(/(?:report a|submit a|log a|add a report|new hazard)\s+(.+)/i);
    const title = titleMatch ? titleMatch[1].trim() : "New hazard report";
    return { type: "create_report", title, place: "", category: "other", severity: "moderate" };
  }
  if (lower.includes("connect") && lower.includes("email")) return { type: "connect_email" };
  if (lower.includes("weather") || lower.includes("rain") || lower.includes("temperature") || lower.includes("forecast") || lower.includes("snow") || lower.includes("wind")) {
    const locMatch = lower.match(/(?:in|at|for|near)\s+([a-z\s,]+)/);
    return { type: "weather", location: locMatch ? locMatch[1].trim() : "current location" };
  }
  if (lower.includes("where is") || lower.includes("find") || lower.includes("locate") || lower.includes("address of") || lower.includes("map of")) {
    const q = lower.replace(/(?:where is|find|locate|address of|map of)\s*/, "").trim() || "New York";
    return { type: "geocode", query: q };
  }
  if (lower.includes("report") || lower.includes("hazard") || lower.includes("road") || lower.includes("signal") || lower.includes("accident") || lower.includes("flood")) {
    return { type: "search_reports", query: lower.replace(/(?:show|find|search|list|get)\s*(?:me\s*)?(?:all\s*)?(?:road\s*)?reports?\s*(?:about|for|near)?\s*/, "").trim() };
  }
  if (lower.includes("inbox") || lower.includes("email") || lower.includes("message") || lower.includes("summar") || lower.includes("travel mail")) {
    return { type: "summarize_inbox" };
  }
  return { type: "chat", text: input };
}

function weatherCodeText(code: number): string {
  const map: Record<number, string> = {
    0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Foggy", 48: "Rime fog", 51: "Light drizzle", 53: "Moderate drizzle",
    55: "Dense drizzle", 61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain",
    66: "Freezing rain", 67: "Freezing rain", 71: "Slight snow", 73: "Moderate snow",
    75: "Heavy snow", 77: "Snow grains", 80: "Rain showers", 81: "Rain showers",
    82: "Violent showers", 85: "Snow showers", 86: "Snow showers",
    95: "Thunderstorm", 96: "Thunderstorm with hail", 99: "Thunderstorm with hail",
  };
  return map[code] || "Unknown conditions";
}

async function getWeather(lat: number, lng: number): Promise<{
  current: { temperature_2m: number; relative_humidity_2m: number; weather_code: number; wind_speed_10m: number; apparent_temperature?: number };
  daily: { weather_code: number[]; temperature_2m_max: number[]; temperature_2m_min: number[]; precipitation_probability_max: number[]; time: string[] };
}> {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=3`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Weather API returned ${res.status}`);
  return await res.json();
}

async function geocode(query: string): Promise<{ lat: number; lng: number; label: string; country?: string } | null> {
  const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=1&language=en&format=json`;
  const res = await fetch(url);
  if (!res.ok) return null;
  const data = await res.json();
  if (!data.results || data.results.length === 0) return null;
  const r = data.results[0];
  return { lat: r.latitude, lng: r.longitude, label: `${r.name}${r.admin1 ? ", " + r.admin1 : ""}`, country: r.country };
}

function formatWeatherText(w: { current: { temperature_2m: number; weather_code: number; wind_speed_10m: number; relative_humidity_2m: number } }, label: string): string {
  const c = w.current;
  return `**Weather in ${label}** — ${weatherCodeText(c.weather_code)}, ${Math.round(c.temperature_2m)}°C. Humidity ${c.relative_humidity_2m}%, wind ${Math.round(c.wind_speed_10m)} km/h.`;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });

  try {
    const body = await req.json() as { messages?: ChatMessage[]; action?: AgentAction; user_lat?: number; user_lng?: number; conversation_id?: string };
    const messages = body.messages || [];
    const lastUserMsg = [...messages].reverse().find(m => m.role === "user");
    const action = body.action || (lastUserMsg ? classifyIntent(lastUserMsg.content) : { type: "chat", text: "" } as AgentAction);
    const supabaseUrl = Deno.env.get("SUPABASE_URL") || "";
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
    const supabase = createClient(supabaseUrl, serviceKey);

    let response = "";
    let card_type: string | null = null;
    let card_data: Record<string, unknown> = {};

    if (action.type === "weather") {
      let lat = action.lat ?? body.user_lat ?? 40.7128;
      let lng = action.lng ?? body.user_lng ?? -74.006;
      let label = action.location;
      if (action.location && action.location !== "current location") {
        const geo = await geocode(action.location);
        if (geo) { lat = geo.lat; lng = geo.lng; label = geo.label; }
      } else { label = "your location"; }
      const weather = await getWeather(lat, lng);
      response = formatWeatherText(weather, label);
      const c = weather.current;
      const d = weather.daily;
      card_type = "weather";
      card_data = {
        location: label, lat, lng,
        current: { temp: c.temperature_2m, humidity: c.relative_humidity_2m, code: c.weather_code, condition: weatherCodeText(c.weather_code), wind: c.wind_speed_10m, feels_like: c.apparent_temperature ?? c.temperature_2m },
        forecast: d.weather_code.map((code, i) => ({ date: d.time[i], condition: weatherCodeText(code), code, high: d.temperature_2m_max[i], low: d.temperature_2m_min[i], rain_chance: d.precipitation_probability_max[i] })),
      };
    } else if (action.type === "geocode") {
      const geo = await geocode(action.query);
      if (geo) {
        response = `**${geo.label}** is located at ${geo.lat.toFixed(4)}, ${geo.lng.toFixed(4)}${geo.country ? `, ${geo.country}` : ""}.`;
        card_type = "geocode";
        card_data = { ...geo };
      } else {
        response = `I couldn't find a place called "${action.query}". Try a more specific name.`;
      }
    } else if (action.type === "search_reports") {
      let query = supabase.from("reports").select("id, title, location_label, severity, category, created_at, lat, lng").order("created_at", { ascending: false }).limit(10);
      if (action.query) query = query.or(`title.ilike.%${action.query}%,location_label.ilike.%${action.query}%,category.ilike.%${action.query}%`);
      const { data: reports, error } = await query;
      if (error) throw error;
      if (reports && reports.length > 0) {
        const levelFor = (s: string) => s === "severe" ? "High" : s === "moderate" ? "Medium" : "Low";
        response = `**Found ${reports.length} road report${reports.length > 1 ? "s" : ""}**${action.query ? ` matching "${action.query}"` : ""}:\n` + reports.map((r: { title: string; location_label: string; severity: string; category: string }) => `• ${r.title} — ${r.location_label} (${levelFor(r.severity)})`).join("\n");
        card_type = "reports";
        card_data = { reports: reports.map((r: { id: string; title: string; location_label: string; severity: string; category: string; lat: number | null; lng: number | null; created_at: string }) => ({ ...r, level: levelFor(r.severity) })) };
      } else {
        response = `No road reports found${action.query ? ` matching "${action.query}"` : ""}. Want me to log a new one?`;
      }
    } else if (action.type === "create_report") {
      const { data: report, error } = await supabase.from("reports").insert({ title: action.title, location_label: action.place || "Unspecified location", category: action.category, severity: action.severity, status: "submitted" }).select("id, title, location_label, severity, category").single();
      if (error) throw error;
      response = `**Report submitted.** "${report.title}" has been logged${report.location_label !== "Unspecified location" ? ` at ${report.location_label}` : ""} and is now visible on the live map.`;
      card_type = "report_created";
      card_data = { report };
    } else if (action.type === "book_ticket") {
      if (!action.origin || !action.destination) {
        response = "Tell me the route and I’ll order it through TravBud. Try: **Book a train from Boston to New York on Friday**.";
      } else {
        const confirmationCode = `TB-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
        const fareCents = action.travel_mode === "flight" ? 12900 : action.travel_mode === "bus" ? 4200 : action.travel_mode === "ferry" ? 3500 : 6800;
        const { data: order, error } = await supabase.from("ticket_orders").insert({ origin: action.origin, destination: action.destination, travel_mode: action.travel_mode, departure_date: action.departure_date, traveler_count: action.traveler_count, fare_cents: fareCents, currency: "USD", status: "confirmed", confirmation_code: confirmationCode }).select("origin, destination, travel_mode, departure_date, traveler_count, fare_cents, currency, confirmation_code").maybeSingle();
        if (error || !order) throw error || new Error("Ticket order could not be created");
        response = `**TravBud ticket confirmed.** Your ${action.travel_mode} from ${order.origin} to ${order.destination} is reserved for ${order.departure_date}. Confirmation **${order.confirmation_code}**.`;
        card_type = "ticket_order";
        card_data = { order };
      }
    } else if (action.type === "connect_email") {
      const { data: existing } = await supabase.from("email_messages").select("id").limit(1);
      if (existing && existing.length > 0) {
        response = "Your email is already connected. I can see your travel messages in the inbox.";
      } else {
        const { error } = await supabase.from("email_messages").insert([
          { sender: "reservations@grandhotel.example", subject: "Booking confirmation — Grand Hotel, 3 nights", body: "Your reservation #GH-88423 is confirmed for check-in Nov 3, check-out Nov 6. Check-in 3:00 PM, check-out 11:00 AM. Address: 200 Harbor Ave.", category: "hotel", is_demo: true },
          { sender: "noreply@railbooker.example", subject: "Your train itinerary — TR-4517", body: "Train TR-4517 departs Central Station at 8:15 AM on Nov 3, arrives Lake City at 11:50 AM. Coach 4, Seat 22.", category: "transit", is_demo: true },
          { sender: "alerts@railbooker.example", subject: "Schedule change notice for TR-4517", body: "Due to track maintenance, train TR-4517 on Nov 3 departs at 9:05 AM, arriving Lake City at 12:40 PM.", category: "change", is_demo: true },
        ]);
        if (error) throw error;
        response = "**Email connected.** I've synced 3 travel messages — a hotel booking, a train itinerary, and a schedule change. Ask me to summarize your inbox to see the highlights.";
      }
    } else if (action.type === "summarize_inbox") {
      const { data: emails, error } = await supabase.from("email_messages").select("sender, subject, body, category, received_at").order("received_at", { ascending: false }).limit(10);
      if (error) throw error;
      if (emails && emails.length > 0) {
        response = `**Travel inbox — ${emails.length} message${emails.length > 1 ? "s" : ""}:**\n` + emails.map((e: { sender: string; subject: string; category: string; body: string }) => `• **${e.subject}** from ${e.sender.split("@")[0]} — ${e.category.toUpperCase()}`).join("\n");
        card_type = "inbox";
        card_data = { emails: emails.map((e: { id?: string; sender: string; subject: string; body: string; category: string; received_at: string }) => ({ sender: e.sender.split("@")[0].split(".").pop() || e.sender, subject: e.subject, preview: e.body.slice(0, 120), category: e.category, received_at: e.received_at })) };
      } else {
        response = "Your travel inbox is empty. Say \"connect my email\" and I'll sync your travel messages.";
      }
    } else {
      const lower = (lastUserMsg?.content || "").toLowerCase();
      if (!lower || lower.includes("hello") || lower.includes("hi") || lower.includes("hey") || lower.includes("help")) {
        response = "I'm TravBud, your AI travel and safety agent.\n\nI can:\n• **Order tickets** — \"Book a train from Boston to New York\"\n• **Check live weather** — \"Weather in Paris?\"\n• **Search road reports** — \"Show road reports near Hill Road\"\n• **Log a hazard** — \"Report a flooded road on 5th Ave\"\n• **Find places** — \"Where is Grand Central?\"\n• **Connect & summarize email** — \"Connect my email\" or \"Summarize my inbox\"\n• **Track your route** — share your location and I'll monitor nearby hazards\n\nWhat can I help you with?";
      } else if (lower.includes("what can you do") || lower.includes("who are you") || lower.includes("your name")) {
        response = "I'm TravBud, your AI travel and safety agent. I can order train, bus, flight, and ferry tickets, connect to live weather and road reports, search places, and summarize your travel inbox.\n\nTry: **Book a train from Boston to New York**.";
      } else if (lastUserMsg?.content) {
        response = `I understand you're asking about "${lastUserMsg.content}". I can order TravBud tickets, check weather, search road hazards, find places, summarize travel email, and track your route. What would you like me to arrange?`;
      } else {
        response = "I'm TravBud, your AI travel and safety agent. Ask me to order a ticket, check weather, find a place, or review your travel inbox.";
      }
    }

    return new Response(JSON.stringify({ response, action: action.type, card_type, card_data }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: (err as Error).message || "Unknown error", response: "I ran into an issue processing that. Please try again." }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
